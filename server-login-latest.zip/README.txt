Instalare dependencies:
	npm install

Pornire server:
	npm run devStart